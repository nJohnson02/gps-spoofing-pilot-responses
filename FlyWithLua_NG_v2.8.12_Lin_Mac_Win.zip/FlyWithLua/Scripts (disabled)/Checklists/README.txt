This subdirectory must be copied into:
X-Plane 11/Resources/plugins/FlyWithLua/Scripts

It is a data storage for checklists if you use the script "display clist.lua".

If you do not use the checklist script, you do not need to copy it into the Scripts directory.

For a more detailed info please read this manual:
X-Plane 11/Resources/plugins/FlyWithLua/Documentation/FlyWithLua_Checklists_Manual_EN.pdf

Enjoy!